It needs Java 15 or above.

export JAVA_HOME=<jdk15 folder>
export PATH=$JAVA_HOME/bin:$PATH

_Build_

./gradlew clean build

This produces a Fat Jar : app/build/libs/graphTest.jar


_Running the Program_

Example Run:
java -jar app/build/libs/graphTest.jar --input-file=/home/praveen/Documents/jobs-after-br/ethic/ethic-test/graph.txt --op=maxDistance --max-limit=30 --route=AC
For help :
java -jar app/build/libs/graphTest.jar --help


--input-file is absolute path to an input text file. This file has one edges defined on each line. Please see graph.txt for sample.
--op = routeDistance|maxStops|maxDistance|shortestDistance
--route = Start and End cities (eg AC) for _maxStops|maxDistance|shortestDistance_ commands. Cities to visit for _routeDistance_ command e.g. ACBE 

_To run Tests:_ ./gradlew clean test

Limitations:
 _the code doesn't handle circular paths. It visits a city only once._ 
 _Test coverage is minimal. Time permitting, we should add many tests dealing with edge cases such as disconnected graphs, large graphs, 
graphs with only one city, two cities, graphs with multiple circular paths, invalid graphs with same city multiple times, invalid distances etc
