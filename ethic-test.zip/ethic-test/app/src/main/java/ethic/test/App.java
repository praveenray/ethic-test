package ethic.test;

import ethic.test.models.RouteDistance;
import ethic.test.models.TravelGraph;
import picocli.CommandLine;

public class App {
    public static void main(String[] args) {

        Commands commands = new Commands();
        CommandLine cline = new CommandLine(commands);
        cline.parseArgs(args);
        if (cline.isUsageHelpRequested()) {
            cline.usage(System.out);
        }

        String error = commands.validate();
        if (error != null) {
            System.err.println(error);
        } else {
            TravelGraph graph = TravelGraph.fromFile(commands.inputFile);
            runCommand(graph, commands);
        }
    }

    private static void runCommand(TravelGraph graph, Commands commands) {
        Object output = switch (commands.ops) {
            case routeDistance -> graph.distanceAlongRoute(commands.route);
            case maxDistance -> graph.findRoutesWithMaxCost(commands.route.charAt(0), commands.route.charAt(1), commands.maxLimit);
            case maxStops -> graph.findRoutesWithMaxStops(commands.route.charAt(0), commands.route.charAt(1), commands.maxLimit);
            case shortestDistance -> graph.shortestPathDijkstra(commands.route.charAt(0), commands.route.charAt(1));
            default -> throw new IllegalArgumentException("Invalid Operation " + commands.ops);
        };
        if (output instanceof RouteDistance) {
            RouteDistance result = (RouteDistance) output;
            if (result.getError() == null) {
                System.out.println("Distance: " + result.getDistance());
            } else {
                System.err.println(result.getError());
            }
        } else {
            System.out.println("Result: " + output);
        }
    }
}
