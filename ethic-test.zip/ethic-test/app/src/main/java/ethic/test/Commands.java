package ethic.test;

import picocli.CommandLine;

import java.nio.file.Path;

public class Commands {
    @CommandLine.Option(names = "--input-file", description = "Input File to read from", required = true)
    Path inputFile;

    @CommandLine.Option(names = "--op", description = "Operation to perform", required = true)
    Operations ops;

    @CommandLine.Option(names = "--max-limit", description = "Max Number of Stops or Max Distance for maxStops and maxDistance commands")
    int maxLimit = -1;

    @CommandLine.Option(names = "--route", required = true, description = "Route to search. Any number of letters for routeDistance command. Two letters for source and destination for other commands")
    String route;

    @CommandLine.Option(names = "--help", usageHelp = true, description = "Help Message")
    private boolean helpRequested;

    public String validate() {
        String error = null;
        if (ops != Operations.routeDistance && maxLimit == -1) {
            error = "--max-limit must be specified";
        }
        return error;
    }
}
