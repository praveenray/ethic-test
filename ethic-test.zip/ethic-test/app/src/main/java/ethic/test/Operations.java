package ethic.test;

public enum Operations {
    routeDistance,
    maxStops,
    maxDistance,
    shortestDistance;
}
