package ethic.test.models;

import lombok.Value;

@Value
public class RouteDistance {
    private String error;
    private long distance;

    public RouteDistance(String error) {
        this.error = error;
        this.distance = -1;
    }

    public RouteDistance(long distance) {
        this.distance = distance;
        this.error = null;
    }
}
