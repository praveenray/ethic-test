package ethic.test.models;

import lombok.Value;
import lombok.With;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Value
public class TravelGraph {
    private static final int MAX_CITIES = Integer.valueOf('z' - 'a' + 1);
    private static final int MAX_WEIGHT = 100;

    private Integer[][] adjacencyMatrix = new Integer[MAX_CITIES][MAX_CITIES];

    public TravelGraph(String[] paths) {
        if (paths == null || paths.length == 0) {
            throw new IllegalArgumentException("Input paths for DAG can not be null or empty");
        }
        buildMatrixFromPaths(paths);
    }

    public static TravelGraph fromFile(Path graphSpecFile) {
        try {
            List<String> lines = Files.readAllLines(graphSpecFile).stream()
                    .filter(s -> s != null)
                    .map(l -> l.trim())
                    .filter(s -> s.length() == 3)
                    .collect(Collectors.toList());
            return new TravelGraph(lines.toArray(String[]::new));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public RouteDistance distanceAlongRoute(String routeSpec) {
        long distance = 0;
        if (routeSpec != null) {
            routeSpec = routeSpec.toUpperCase();
            for (int i = 0; i < routeSpec.length(); i++) {
                int startCity = validCharIndex(routeSpec, i);
                if ((i + 1) < routeSpec.length()) {
                    int nextCity = validCharIndex(routeSpec, i + 1);
                    Integer weight = adjacencyMatrix[startCity][nextCity];
                    if (weight != null) {
                        distance += weight;
                    } else {
                        return new RouteDistance("NO SUCH ROUTE");
                    }
                }
            }
        }
        return new RouteDistance(distance);
    }

    public int findRoutesWithMaxStops(char startCity, char endCity, int maxStopsAllowed) {
        Trip trip = tripCities(startCity, endCity);
        List<String> matches = new ArrayList<>();
        findRoutes(new CurrentPathNode(trip.getStartCity(), 0), trip.getEndCity(), new BitSet(), new ArrayList<>(), matches, maxStopsAllowed, null);

        return matches.size();
    }

    public int findRoutesWithMaxCost(char startCity, char endCity, int maxCostAllowed) {
        Trip trip = tripCities(startCity, endCity);
        List<String> matches = new ArrayList<>();
        findRoutes(new CurrentPathNode(trip.getStartCity(), 0), trip.getEndCity(), new BitSet(), new ArrayList<>(), matches, null, maxCostAllowed);

        return matches.size();
    }

    private void findRoutes(CurrentPathNode thisCity,
                            int endCity,
                            BitSet visited,
                            List<CurrentPathNode> currentPath,
                            List<String> pathsSoFar,
                            Integer maxStopsAllowed,
                            Integer maxCostAllowed
    ) {
        // dfs
        boolean firstStop = currentPath.isEmpty();
        currentPath.add(new CurrentPathNode(thisCity.getCity(), totalCost(currentPath, thisCity)));
        if (endCity == thisCity.getCity() && !firstStop) {
            pathsSoFar.add(nodesToCities(currentPath));
            visited.clear(thisCity.getCity());
            currentPath.remove(currentPath.size() - 1);
        } else {
            List<CurrentPathNode> neighbors = visited.get(thisCity.getCity()) ? List.of() : findNeighbors(thisCity.getCity());
            visited.set(thisCity.getCity());
            if (!constraintsBreached(maxStopsAllowed, maxCostAllowed, currentPath)) { // no need to proceed further if we have breached number of stops already
                neighbors.stream().forEach(n -> findRoutes(n, endCity, visited, currentPath, pathsSoFar, maxStopsAllowed, maxCostAllowed));
            }
            currentPath.remove(currentPath.size() - 1);
            visited.clear(thisCity.getCity());
        }
    }

    public int shortestPathDijkstra(char startCity, char endCity) {
        int[] distancesFromStart = new int[adjacencyMatrix.length];
        BitSet visited = new BitSet();
        Arrays.fill(distancesFromStart, -1); // -1 => infinity

        Trip trip = tripCities(startCity, endCity);
        distancesFromStart[trip.getStartCity()] = 0;

        PriorityQueue<CurrentPathNode> minQueue = new PriorityQueue<>((t0, t1) ->
            Integer.valueOf(distancesFromStart[t0.getCity()]).compareTo(distancesFromStart[t1.getCity()])
        );
        minQueue.add(new CurrentPathNode(trip.getStartCity(), 0));

        while (!minQueue.isEmpty()) {
            CurrentPathNode current = minQueue.poll();

            if (!visited.get(current.getCity())) {
                visited.set(current.getCity());

                List<CurrentPathNode> neighbors = findNeighbors(current.getCity());
                for (CurrentPathNode n : neighbors) {
                    int newCost = distancesFromStart[current.getCity()] + n.getCost();
                    if (distancesFromStart[n.getCity()] == -1 || newCost < distancesFromStart[n.getCity()]) { // -1 is infinite cost
                        distancesFromStart[n.getCity()] = newCost;
                        minQueue.add(n);
                    }
                }
            }
        }

        return distancesFromStart[trip.getEndCity()];
    }


    private Trip tripCities(char start, char end) {
        Character thisUpper = Character.toUpperCase(start);
        Character endUpper = Character.toUpperCase(end);

        int startInt = validCharIndex(thisUpper.toString(), 0);
        int endInt = validCharIndex(endUpper.toString(), 0);
        return new Trip(startInt, endInt);
    }

    private boolean constraintsBreached(Integer maxStopsAllowed, Integer maxCostAllowed, List<CurrentPathNode> currentPath) {
        if (maxStopsAllowed != null) {
            int stopsSoFar = currentPath.size() - 1; // not counting starting node
            stopsSoFar = stopsSoFar < 0 ? 0 : stopsSoFar;
            return stopsSoFar >= maxStopsAllowed;
        } else if (maxCostAllowed != null) {
            int costSoFar = 0;
            if (!currentPath.isEmpty()) {
                costSoFar = currentPath.get(currentPath.size() - 1).getCost();
            }
            return costSoFar >= maxCostAllowed;
        }
        return false;
    }

    private int totalCost(List<CurrentPathNode> currentPath, CurrentPathNode thisCity) {
        if (currentPath.isEmpty()) {
            return thisCity.getCost();
        } else {
            return currentPath.get(currentPath.size() - 1).getCost() + thisCity.getCost();
        }
    }

    private String nodesToCities(List<CurrentPathNode> pathNodes) {
        StringBuilder bldr = new StringBuilder(pathNodes.size());
        pathNodes.stream().map(node -> intToCity(node.getCity())).forEach(c -> bldr.append(c));
        return bldr.toString();
    }

    private List<CurrentPathNode> findNeighbors(int city) {
        int len = adjacencyMatrix[city].length;
        List<CurrentPathNode> neighbors = new ArrayList<>();
        for (int i = 0; i < len; i++) {
            Integer distanceCost = adjacencyMatrix[city][i];
            if (distanceCost != null) {
                neighbors.add(new CurrentPathNode(i, distanceCost));
            }
        }
        return neighbors;
    }

    private void buildMatrixFromPaths(String[] paths) {
        Arrays.stream(paths).forEach(path -> {
            path = path.toUpperCase();

            adjacencyMatrix[validCharIndex(path, 0)][validCharIndex(path, 1)] = validWeight(path);
        });
    }

    private int validCharIndex(String path, int i) {
        if (path.length() < (i + 1)) {
            throw new IllegalArgumentException(String.format("Path % must be at least %d chars", (i + 1)));
        }
        char c = path.charAt(i);
        if (c < 'A' || c > 'Z') {
            throw new IllegalArgumentException("Invalid character " + path.charAt(i));
        }
        return c - 'A';
    }

    private int validWeight(String path) {
        if (path.length() < 3) {
            throw new IllegalArgumentException(String.format("Path Must be at least three chars long (%s)", path));
        }
        int w = path.charAt(2) - '0';
        if (w < 1 || w > MAX_WEIGHT) {
            throw new IllegalArgumentException(String.format("Path %s has invalid weight", path));
        }

        return w;
    }

    private char intToCity(int code) {
        int c = code + 'A';
        return (char) c;
    }

    @Override
    public String toString() {
        StringBuilder bldr = new StringBuilder();
        for (int i = 0; i < MAX_CITIES; i++) {
            int row = 'A' + i;
            bldr.append(Character.toString(row)).append(" ");
            for (int j = 0; j < MAX_CITIES; j++) {
                bldr.append(adjacencyMatrix[i][j]).append(" ");
            }
            bldr.append("\n");
        }
        return bldr.toString();
    }
}

@Value
@With
class CurrentPathNode {
    int city;
    int cost;
}

@Value
class Trip {
    private int startCity;
    private int endCity;
}